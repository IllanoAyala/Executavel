The version of Bottle included here is 0.12.13
commit 7423aa0f64e381507d1e06a6bcab48888baf9a7b

https://github.com/bottlepy/bottle/releases/tag/0.12.13

This package has no dependencies.

No modifications have been made.