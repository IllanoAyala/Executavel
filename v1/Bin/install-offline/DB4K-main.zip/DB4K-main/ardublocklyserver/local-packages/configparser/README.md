# configparser 3.5.0b2
This library brings the updated configparser from Python 3.5 to Python 2.6-3.5.

The ancient ConfigParser module available in the standard library 2.x has seen a major update in Python 3.2. This is a backport of those changes so that they can be used directly in Python 2.6 - 3.5.

This is required mostly due to the Unicode support added.

https://pypi.python.org/pypi/configparser
