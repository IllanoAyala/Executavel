The version of waitress included here is v1.0.2
commit 76b34b8411cc84ef808f4ab266271bf6a77a1071

https://github.com/Pylons/waitress/releases/tag/v1.0.2

This package has no dependencies.

No modifications have been made.