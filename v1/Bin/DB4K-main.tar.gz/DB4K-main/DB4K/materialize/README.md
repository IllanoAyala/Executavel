## Materialize CSS Framework

This folder contains the CSS and Javascript for the Materialize CSS framework.

https://github.com/Dogfalo/materialize

Current version used: >0.97.5 [@09cd7116129c3f3b9879c24f7ff688e8c7da18f2 commit](https://github.com/Dogfalo/materialize/commit/09cd7116129c3f3b9879c24f7ff688e8c7da18f2)

There has been a patch added to the minified javascript file. The issue is described in https://github.com/Dogfalo/materialize/issues/1647 and fixed by un-merged PR https://github.com/Dogfalo/materialize/pull/1691 .
